
import json
import os
import sqlite3
from sqlalchemy.orm import Session
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from textwrap import dedent
from typing import Any, Dict, List, Tuple, Union

import pandas as pd
from crewai import Agent, Crew, Process, Task
from crewai_tools import tool
from langchain.schema import AgentFinish
from langchain.schema.output import LLMResult
from langchain_community.tools.sql_database.tool import (
    InfoSQLDatabaseTool,
    ListSQLDatabaseTool,
    QuerySQLCheckerTool,
    QuerySQLDataBaseTool,
)
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq
import os
from pydantic import BaseModel ,Field

import subprocess
import uvicorn

import pandas as pd
from fastapi import FastAPI,Depends,HTTPException,Path
from fastapi.middleware.cors import CORSMiddleware
from typing import Annotated
from sqlalchemy import create_engine , Column,Integer,String,Text
from sqlalchemy.engine import result


#from database import SessionLocal,Base,engine

import os

import uvicorn

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine
import ssl
import certifi
print(certifi.where())

# PostgreSQL Database -----------------------------------------------------------------------------
db = os.environ.get("POSTGRES_DB")
user = os.environ.get("POSTGRES_USER")
password = os.environ.get("POSTGRES_PASSWORD")

engine = create_engine(f"postgresql+psycopg2://{user}:{password}@pgdb/{db}")
print(engine)
df=pd.read_csv("new_madrid_landmark.csv")
df.to_sql("landmarks",con=engine,if_exists="append",index=False)

# Inititiating logs Database -----------------------------------------------------------------------------

@dataclass
class Event:
    event: str
    timestamp: str
    text: str


def _current_time() -> str:
    return datetime.now(timezone.utc).isoformat()


class LLMCallbackHandler(BaseCallbackHandler):
    def __init__(self, log_path: Path):
        self.log_path = log_path

    def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> Any:
        """Run when LLM starts running."""
        assert len(prompts) == 1
        event = Event(event="llm_start", timestamp=_current_time(), text=prompts[0])
        with self.log_path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(asdict(event)) + "\n")

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> Any:
        """Run when LLM ends running."""
        generation = response.generations[-1][-1].message.content
        event = Event(event="llm_end", timestamp=_current_time(), text=generation)
        with self.log_path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(asdict(event)) + "\n")

#LLM configuration

llm = ChatGroq(
    api_key="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",
    model_name="llama3-70b-8192",
    #callbacks=[LLMCallbackHandler(Path("prompts.jsonl"))],
)

db=SQLDatabase.from_uri(f"postgresql+psycopg2://{user}:{password}@pgdb/{db}")

@tool("list_tables")
def list_tables() -> str:
    """List the available tables in the database"""
    return ListSQLDatabaseTool(db=db).invoke("")



@tool("tables_schema")
def tables_schema(tables: str) -> str:
    """
    Input is a comma-separated list of tables, output is the schema and sample rows
    for those tables. Be sure that the tables actually exist by calling `list_tables` first!
    Example Input: table1, table2, table3
    """
    tool = InfoSQLDatabaseTool(db=db)
    return tool.invoke(tables)



@tool("execute_sql")
def execute_sql(sql_query: str) -> str:
    """Execute a SQL query against the database. Returns the result"""
    return QuerySQLDataBaseTool(db=db).invoke(sql_query)




@tool("check_sql")
def check_sql(sql_query: str) -> str:
    """
    Use this tool to double check if your query is correct before executing it. Always use this
    tool before executing a query with `execute_sql`.
    """
    return QuerySQLCheckerTool(db=db, llm=llm).invoke({"query": sql_query})

## AGENTS Configuration

sql_dev = Agent(
    role="Senior Database Developer",
    goal="Construct and execute SQL queries based on a request",
    backstory=dedent(
        """
        You are an experienced database engineer who is master at creating efficient and complex SQL queries.
        You have a deep understanding of how different databases work and how to optimize queries.
        Use the `list_tables` to find available tables.
        Use the `tables_schema` to understand the metadata for the tables.
        Use the `check_sql` to check your queries for correctness.
        Use the `execute_sql` to execute queries against the database.
    """
    ),
    llm=llm,
    tools=[list_tables, tables_schema, execute_sql, check_sql],
    allow_delegation=False,
)



data_analyst = Agent(
    role="Senior Data Analyst",
    goal="You receive data from the database developer and analyze it",
    backstory=dedent(
        """
        You have deep experience with analyzing datasets using Python.
        Your work is always based on the provided data and is clear,
        easy-to-understand and to the point. You have attention
        to detail and always produce very detailed work (as long as you need).

        The data you are going to be working with is landmark related. 
        The analysis you give is going to be used for event planning,
    """
    ),
    llm=llm,
    allow_delegation=False,
)


report_writer = Agent(
        role='Amazing Travel Concierge',
        goal="""Create the most amazing sightseeing event planning based on the landmark data recieved . """,
        backstory="""Specialist in travel planning and logistics with 
        decades of experience. You will pick the best starting landmark to vist based on location with end landmark that is fitting for the traveler """,
        
       
        llm=llm)

## Task Configuration

extract_data = Task(
    description="Extract data that is required for the query {query}.",
    expected_output="Database result for the query",
    agent=sql_dev,
)



analyze_data = Task(
    description="Analyze the data from the database and write an analysis for {query}. Advise me on what I should visit. Determine which need reservation and give a guide on how to buy them along with their cost.",
    expected_output="Detailed analysis text",
    agent=data_analyst,
    context=[extract_data],
)




write_report = Task(
    description=dedent(
        """
         Create the most amazing sightseeing event planning based on the landmark data recieved .
         You will schedule out and pick the best starting landmark to vist based on location with an end landmark that is fitting for the traveler .
         Also to your best knowledge give a fun fact about each landmark also . Always assume we will start at 8 am some make a timely schedule with that information given. Starting location assume that it is in santiago bernabeau stadium. I dont have data about the madrid stadium but include it in the schedule
    """
    ),
    expected_output="Markdown report",
    agent=report_writer,
    context=[analyze_data],
)


## Assemble Crew


crew = Crew(
    agents=[sql_dev, data_analyst, report_writer],
    tasks=[extract_data, analyze_data, write_report],
    process=Process.sequential,
    verbose=2,
    memory=False,
    output_log_file="crew.log",
)





inputs = {
    "query": "I want to visit all the musuems"
}





# Middleware ------------------------------------------------------------s
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class QueryIn(BaseModel):
    """Defines input for querying via FastAPI app"""

    input_text: str


class QueryOut(BaseModel):
    """Defines input for querying via FastAPI app"""

    input_text: str
    output_text: str


@app.post("/query")
async def chat(
    query_in: QueryIn = QueryIn(input_text="I Want to visit all museums?"),
) -> QueryOut:
    # get output

    # generate output_text
    input_text= {"query": "I want to visit all the musuems"}       
    output_text = crew.kickoff(input_text)

    data = {"input_text": input_text, "output_text": output_text}
    df=pd.DataFrame(data)
    df.to_sql("chat_logs", con=engine, if_exists="append", index=False)
    
    SQL_Q="SELECT * FROM chat_logs"
    Results=engine.execute(SQL_Q)
    table=pd.DataFrame(Results)
    

    return QueryOut(input_text=table.iloc[-1,0], output_text=table.iloc[-1,1])



# @app.get("/history")
# async def get_chat_history():

#     # TODO

#     # get chat history from datatable (SQLAlchemy)

#     # return json of list of chat history rows
#     return


if __name__ == "__main__":
      uvicorn.run("api:app", host="0.0.0.0", port=8080,ssl_ca_certs=certifi.where())
